const { ytmp3, ttdl, igdl, ytmp4, transcript, pindl, mfdl, fbPhoto, ttdl2, fbVideo } = require("./api/downloader.js")
const { tiktoks, pinterest, search, GoogleImage, lyrics } = require("./api/search.js")
const { githubStalk, tiktokStalk, ytStalk, genshinStalk, igStalk } = require("./api/stalking.js")

module.exports = {
  search,
  ytmp3,
  ytmp4,
  transcript,
  pindl,
  tiktoks,
  pinterest,
  githubStalk,
  tiktokStalk,
  ytStalk,
  GoogleImage,
  ttdl,
  igdl,
  genshinStalk,
  mfdl,
  igStalk,
  fbPhoto,
  ttdl2,
  fbVideo,
  lyrics
}
